import numpy as np


def normalize(X):
    """
    Normalize the features in the dataset.
    Each feature will be scaled to have a mean of 0 and a standard deviation of 1.

    Parameters:
    X (numpy.ndarray): The input data matrix to be normalized.

    Returns:
    numpy.ndarray: The normalized data matrix.
    """
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    return (X - mean) / std


def train_test_split(X, y, test_size=0.2, random_state=None):
    """
    Split the dataset into training and testing sets.

    Parameters:
    X (numpy.ndarray): The input data matrix.
    y (numpy.ndarray): The target values.
    test_size (float): The proportion of the dataset to include in the test split.
    random_state (int, optional): Seed used by the random number generator.

    Returns:
    tuple: A tuple containing four elements: (X_train, X_test, y_train, y_test).
    """
    if random_state:
        np.random.seed(random_state)

    indices = np.arange(X.shape[0])
    np.random.shuffle(indices)

    test_set_size = int(len(X) * test_size)
    test_indices = indices[:test_set_size]
    train_indices = indices[test_set_size:]

    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]


def accuracy_score(y_true, y_pred):
    """
    Calculate the accuracy of predictions.

    Parameters:
    y_true (numpy.ndarray): The true target values.
    y_pred (numpy.ndarray): The predicted target values.

    Returns:
    float: The accuracy of the predictions.
    """
    return np.mean(y_true == y_pred)
