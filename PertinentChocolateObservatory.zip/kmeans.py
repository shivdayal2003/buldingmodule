from data_analysis import KMeans
import numpy as np

X = np.array([[1, 2], [2, 3], [3, 4], [5, 6], [8, 9], [9, 10]])
kmeans = KMeans(k=2)
kmeans.fit(X)
print("K-Means Cluster Prediction:", kmeans.predict(np.array([0, 1])))
