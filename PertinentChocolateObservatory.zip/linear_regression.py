from data_analysis import LinearRegression
import numpy as np

X = np.array([[1, 1], [1, 2], [2, 2], [2, 3]])
y = np.dot(X, np.array([1, 2])) + 3
lin_reg = LinearRegression()
lin_reg.fit(X, y)
print("Linear Regression Predictions:", lin_reg.predict(np.array([[3, 5]])))
