from data_analysis import LogisticRegression
import numpy as np

X = np.array([[1, 2], [2, 3], [3, 4], [4, 5]])
y = np.array([0, 0, 1, 1])
log_reg = LogisticRegression()
log_reg.fit(X, y)
print("Logistic Regression Predictions:",
      log_reg.predict(np.array([[1, 3], [3, 5]])))
